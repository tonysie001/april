package com.soul.cases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class CreateBigPhotoCase {
	
	//����ȫ����Ƭ
	@Test
	public void testCreateBigPhoto(WebDriver driver) throws Exception {
		
		System.out.println("======����testCreateBigPhoto()����=======");
		
		// driver.findElement(By.xpath(".//*[@id='summaryNav']/a")).click();//����ҳ����ҵ���ҳ
		Thread.sleep(3000);
		driver.findElement(By.xpath(".//*[@id='pageType_chzn']/a/span"))
				.click();// ͨ��������ѡ������Ϊȫ����Ƭ
		driver.findElement(By.xpath(".//*[@id='pageType_chzn_o_16']")).click();
		Thread.sleep(1000);
		driver.findElement(
				By.xpath("//*[@id='itemContainer']/li[1]/div/div/a[2]"))
				.click();
		Thread.sleep(500);
		driver.findElement(By.id("imgMask0")).click();
		driver.findElement(By.xpath(".//*[@id='popupDiv']/div/div[2]/input[3]"))
				.click();
		driver.findElement(By.id("imgSrc"))
				.sendKeys(
						"http://192.168.2.185/img/static/memento/online/book_banner.png");
		driver.findElement(By.xpath(".//*[@id='popupDiv']/div/div[2]/input[3]"))
				.click();
		driver.findElement(By.xpath(" .//*[@id='imgSure']/input[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".aui_close")).click();
		Thread.sleep(3000);
		driver.findElement(By.cssSelector(".aui_state_highlight")).click();
		Thread.sleep(3000);
		driver.findElement(By.cssSelector(".progress>div>canvas")).click();
		Thread.sleep(3000);
		driver.findElement(
				By.xpath(".//*[@id='frameContent']/div[2]/div[2]/input[3]"))
				.click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".aui_state_highlight")).click();
		Thread.sleep(2000);
	}
}
