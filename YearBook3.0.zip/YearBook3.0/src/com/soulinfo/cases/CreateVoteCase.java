package com.soulinfo.cases;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.soulinfo.entity.YBEntity;
import com.soulinfo.util.BasicElements;
import com.soulinfo.util.CommonElements;

public class CreateVoteCase {
	private final static Logger logger = LoggerFactory.getLogger(Test.class);
	BasicElements element = new BasicElements();
	CommonElements common = new CommonElements();

	/**
	 * ������ͶƱ
	 * 
	 * @param title
	 *            ����
	 * @param option1
	 *            ѡ��һ
	 * @param option2
	 *            ѡ���
	 * @param option3
	 *            ѡ����
	 * @throws InterruptedException
	 */	
	public void testCreateVote(YBEntity yb) throws InterruptedException {
		logger.info("======����testCreateVote()����=======");

		element.findByLinkTextClick("������ҳ");
		element.findByLinkTextClick("����ͶƱ");

		for (int i = 1; i < 4; i++) {
			logger.info("�೤������" + i + "��ͶƱ");
			element.findByCssClick(".onbtnCss03");

			element.findByXpathSendKeys(
					".//*[@id='popupDiv']/div/div[1]/table/tbody/tr[1]/td[2]/input",
					yb.getTitle());
			element.findByXpathSendKeys(
					".//*[@id='popupDiv']/div/div[1]/table/tbody/tr[2]/td[2]/input",
					yb.getOption1());
			element.findByXpathSendKeys(
					".//*[@id='popupDiv']/div/div[1]/table/tbody/tr[3]/td[2]/input",
					yb.getOption2());
			element.findByXpathSendKeys(
					".//*[@id='popupDiv']/div/div[1]/table/tbody/tr[4]/td[2]/input",
					yb.getOption3());
			
			element.findByIDClick("createVote");

			common.getScreen("createvote");
			Thread.sleep(2000);
		}
		element.findByLinkTextClick("������ҳ");
	}
}
