package com.soulinfo.cases;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.soulinfo.entity.YBEntity;
import com.soulinfo.util.BasicElements;
import com.soulinfo.util.CommonElements;

public class LoginCase {
	private final static Logger logger = LoggerFactory.getLogger(Test.class);
	BasicElements element = new BasicElements();
	CommonElements common = new CommonElements();

	/**
	 * ��¼
	 * 
	 * @param username
	 * @param password
	 * @param code
	 * @throws InterruptedException
	 */
	public void testLogin(YBEntity yb)
			throws InterruptedException {
		logger.info("======����testStuLogin()����=======");
		// �����¼
				element.findByLinkTextClick("��¼");

				// �����û���
				element.findByXpathClear("//*[@id='loginName']");
				element.findByXpathSendKeys("//*[@id='loginName']", yb.getUsername());

				// ��������
				element.findByIDClear("logpass");
				element.findByIDSendKeys("logpass", yb.getPassword());

				// ������֤��
				element.findByIDClear("inputcode");
				element.findByIDSendKeys("inputcode", yb.getCode());
				Thread.sleep(500);
				
				common.getScreen("Login");

				// �������
				element.findByIDClick("loginBtn");
				
				common.getScreen("index");
				logger.info("��¼�ɹ���" + yb.getUsername());
	}

	/**
	 * ע��
	 */
	
	public void testLogout() {
		logger.info("======����testLogout()����=======");

		// ���ע����ť
		element.findByLinkTextClick("ע��");
		logger.info("ע���ɹ�");
	}
}
