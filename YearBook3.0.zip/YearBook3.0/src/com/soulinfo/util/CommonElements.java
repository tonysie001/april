package com.soulinfo.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * ��װ���÷���
 * 
 * @author weiwei.zhang
 * @date 2015.5.5
 * @version 1.0
 */
public class CommonElements {

	Driver d = new Driver();
	WebDriver driver = d.getDriver();
	String SCREENURL = Driver.getPropertyString("SCREENURL");
	String EXTENSION = Driver.getPropertyString("EXTENSION");

	/**
	 * ִ��JS�ű�
	 * 
	 * @param by
	 * @param parameter
	 */
	public void executeScript(By by, String parameter) {
		WebElement element = driver.findElement(by);
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor) driver).executeScript(parameter, element);
		}
	}

	/**
	 * ��ȡ��Ļ
	 * 
	 * @param filepath
	 */
	public void getScreen(String filename) {
		File screenShotFile = ((TakesScreenshot) driver)
				.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(screenShotFile, new File(SCREENURL + times()+filename
					+ EXTENSION));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * ����1-i�������
	 * 
	 * @param i
	 * @return random
	 */
	public int testRandom(int i) {
		int random = (int) (i * Math.random() + 1);
		return random;
	}

	/**
	 * ��ȡ��ǰϵͳʱ��
	 * 
	 * @return String time
	 */
	public String time() {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return df.format(new Date());
	}
	
	/**
	 * ��ȡ��ǰϵͳʱ��
	 * 
	 * @return String time
	 */
	public String times() {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		return df.format(new Date());
	}
}
