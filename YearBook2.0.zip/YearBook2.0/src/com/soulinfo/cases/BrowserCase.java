package com.soulinfo.cases;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.soulinfo.util.BrowserElements;
import com.soulinfo.util.CommonElements;

public class BrowserCase {
	private final static Logger logger = LoggerFactory.getLogger(Test.class);
	BrowserElements browser = new BrowserElements();
	CommonElements common = new CommonElements();

	/**
	 * �������
	 */
	@Test
	public void openBrowser() {
		browser.openBrowser();
		logger.info("�������ʱ�䣺" + new Date(System.currentTimeMillis()));
	}

	/**
	 * �˳������
	 */
	@Test
	public void closeBrowser() {
		logger.info("�ر������ʱ�䣺" + new Date(System.currentTimeMillis()));
		browser.closeBrowser();
	}
}
