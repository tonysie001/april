package com.soulinfo.cases;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.soulinfo.util.BasicElements;
import com.soulinfo.util.BrowserElements;
import com.soulinfo.util.CommonElements;

public class CreateBigPhotoCase {
	private final static Logger logger = LoggerFactory.getLogger(Test.class);
	BrowserElements browser = new BrowserElements();
	BasicElements element = new BasicElements();
	CommonElements common = new CommonElements();

	/**
	 * ����ȫ����Ƭ
	 * 
	 * @throws InterruptedException
	 */
	@Test
	public void testCreateBigPhoto() throws InterruptedException {

		logger.info("======����testCreateBigPhoto()����=======");

		// ����ҳ����ҵ���ҳ
		element.findByLinkTextClick("�ҵ���ҳ");

		// ͨ��������ѡ������Ϊȫ����Ƭ
		element.findByXpathClick(".//*[@id='pageType_chzn']/a/span");
		element.findByXpathClick(".//*[@id='pageType_chzn_o_16']");
		Thread.sleep(500);

		//����༭��ť
		element.findByXpathClick("//*[@id='itemContainer']/li[1]/div/div/a[2]");
		Thread.sleep(500);
		element.findByIDClick("imgMask0");
		element.findByXpathClick(".//*[@id='popupDiv']/div/div[2]/input[3]");
		element.findByIDSendKeys("imgSrc",
				"http://192.168.2.185/img/static/memento/online/book_banner.png");
		element.findByXpathClick(".//*[@id='popupDiv']/div/div[2]/input[3]");
		element.findByXpathClick(".//*[@id='imgSure']/input[1]");
		element.findByCssClick(".aui_close");
		element.findByCssClick(".aui_state_highlight");

		common.getScreen("bigphoto");	
		
		element.findByCssClick(".progress>div>canvas");
		element.findByXpathClick(".//*[@id='frameContent']/div[2]/div[2]/input[3]");
		element.findByCssClick(".aui_state_highlight");
		
		browser.refresh();
		Thread.sleep(3000);		

		logger.info("ȫ����Ƭ�������");
	}
}
