package com.soulinfo.cases;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.soulinfo.util.BasicElements;
import com.soulinfo.util.CommonElements;

public class LoginCase {
	private final static Logger logger = LoggerFactory.getLogger(Test.class);
	BasicElements element = new BasicElements();
	CommonElements common = new CommonElements();

	/**
	 * ѧ����¼
	 * 
	 * @param username
	 * @param password
	 * @param code
	 * @throws InterruptedException
	 */
	@Test(dataProvider = "testLoginStuDate", dataProviderClass = ExcelDataProvider.class)
	public void testStuLogin(String username, String password, String code)
			throws InterruptedException {
		logger.info("======����testStuLogin()����=======");
		login(username, password, code);
	}

	/**
	 * �೤��¼
	 * 
	 * @param username
	 * @param password
	 * @param code
	 * @throws Exception
	 */
	@Test(dataProvider = "testLoginClaDate", dataProviderClass = ExcelDataProvider.class)
	public void testClaLogin(String username, String password, String code)
			throws Exception {
		logger.info("======����testClaLogin()����=======");
		login(username, password, code);
	}

	@Test
	public void login(String username, String password, String code)
			throws InterruptedException {

		// �����¼
		element.findByLinkTextClick("��¼");

		// �����û���
		element.findByXpathClear("//*[@id='loginName']");
		element.findByXpathSendKeys("//*[@id='loginName']", username);

		// ��������
		element.findByIDClear("logpass");
		element.findByIDSendKeys("logpass", password);

		// ������֤��
		element.findByIDClear("inputcode");
		element.findByIDSendKeys("inputcode", code);
		Thread.sleep(500);
		
		common.getScreen("Login");

		// �������
		element.findByIDClick("loginBtn");
		
		common.getScreen("index");
		logger.info("��¼�ɹ���" + username);
	}

	/**
	 * ע��
	 */
	@Test
	public void testLogout() {
		logger.info("======����testLogout()����=======");

		// ���ע����ť
		element.findByLinkTextClick("ע��");
		logger.info("ע���ɹ�");
	}
}
