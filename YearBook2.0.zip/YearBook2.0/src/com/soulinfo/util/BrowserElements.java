package com.soulinfo.util;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

public class BrowserElements {

	Driver d = new Driver();
	WebDriver driver = d.getDriver();
	String URL = Driver.getPropertyString("BASE_URL");

	/**
	 * �������ָ��URL
	 * 
	 * @param url
	 */
	public void openBrowser() {
		driver.get(URL);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	/**
	 * ������˳�
	 */
	public void closeBrowser() {
		driver.quit();
	}

	/**
	 * �����ˢ��
	 */
	public void refresh() {
		driver.navigate().refresh();
	}

	/**
	 * ���������
	 */
	public void back() {
		driver.navigate().back();
	}

	/**
	 * �����ǰ��
	 */
	public void forward() {
		driver.navigate().forward();
	}
}
